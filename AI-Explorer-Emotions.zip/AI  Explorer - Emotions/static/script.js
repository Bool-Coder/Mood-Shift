let rezultatText = "";
let rezultatCamera = "";

let emotieText = "";
let emotieCamera = "";

const expresiiRO = {
    happy: "😊 Fericit",
    sad: "😢 Trist",
    angry: "😠 Furios",
    neutral: "😐 Neutru",
    surprised: "😲 Surprins",
    fearful: "😨 Anxios",
    disgusted: "🤢 Dezgustat"
};

const mapareCamera = {
    happy: "fericit",
    sad: "trist",
    angry: "furios",
    fearful: "anxios",
    neutral: "neutru",
    surprised: "surprins",
    disgusted: "dezgustat"
};


// =========================
// ÎNCĂRCARE MODELE AI
// =========================

window.addEventListener("load", async () => {

    const status =
        document.getElementById(
            "camera-status"
        );

    try {

        status.innerHTML =
            "⏳ Se încarcă modelele AI...";

        await faceapi.nets.tinyFaceDetector.loadFromUri(
            "/models"
        );

        await faceapi.nets.faceExpressionNet.loadFromUri(
            "/models"
        );

        status.innerHTML =
            "✅ Modelele AI au fost încărcate.";

    } catch (error) {

        console.error(error);

        status.innerHTML =
            "❌ Eroare la încărcarea modelelor.";

    }

});


// =========================
// ANALIZĂ TEXT
// =========================

async function analizeazaText() {

    const text =
        document.getElementById(
            "text"
        ).value.trim();

    if (!text) {

        alert(
            "Scrie un text mai întâi!"
        );

        return;
    }

    try {

        const response =
            await fetch("/analiza", {

                method: "POST",

                headers: {
                    "Content-Type":
                    "application/json"
                },

                body: JSON.stringify({
                    text: text
                })

            });

        const data =
            await response.json();

        emotieText =
            data.emotie;

        rezultatText =
            `${data.emoji} ${data.emotie}`;

        document.getElementById(
            "rezultat-text"
        ).innerHTML =
            `<b>Text:</b> ${rezultatText}`;

        genereazaConcluzie();

    } catch (error) {

        console.error(error);

        document.getElementById(
            "rezultat-text"
        ).innerHTML =
            "❌ Eroare la analiza textului.";

    }

}


// =========================
// PORNIRE CAMERĂ
// =========================

async function pornesteCamera() {

    try {

        const video =
            document.getElementById(
                "video"
            );

        const stream =
            await navigator.mediaDevices.getUserMedia({

                video: true

            });

        video.srcObject =
            stream;

        document.getElementById(
            "camera-status"
        ).innerHTML =
            "✅ Camera este pornită.";

    } catch (error) {

        console.error(error);

        alert(
            "Nu pot accesa camera."
        );

    }

}


// =========================
// DETECTARE EMOȚIE
// =========================

async function detecteazaEmotie() {

    const video =
        document.getElementById(
            "video"
        );

    try {

        const detection =
            await faceapi

                .detectSingleFace(
                    video,
                    new faceapi.TinyFaceDetectorOptions()
                )

                .withFaceExpressions();

        if (!detection) {

            alert(
                "Nu a fost detectată nicio față."
            );

            return;
        }

        const dominant =

            Object.entries(
                detection.expressions
            )

            .reduce(
                (a, b) =>
                    a[1] > b[1]
                        ? a
                        : b
            );

        const emotie =
            dominant[0];

        const procent =
            Math.round(
                dominant[1] * 100
            );

        emotieCamera =
            mapareCamera[
                emotie
            ];

        rezultatCamera =
            expresiiRO[
                emotie
            ];

        document.getElementById(
            "rezultat-camera"
        ).innerHTML =
            `<b>Cameră:</b> ${rezultatCamera} (${procent}%)`;

        afiseazaEmotiiDetaliate(
            detection.expressions
        );

        genereazaConcluzie();

    } catch (error) {

        console.error(error);

        document.getElementById(
            "rezultat-camera"
        ).innerHTML =
            "❌ Eroare la detectarea emoției.";

    }

}


// =========================
// EMOȚII DETALIATE
// =========================

function afiseazaEmotiiDetaliate(
    expresii
) {

    const container =
        document.getElementById(
            "emotii-detaliate"
        );

    container.innerHTML =

        Object.entries(expresii)

        .sort(
            (a, b) =>
                b[1] - a[1]
        )

        .map(([emo, val]) => `

            <div class="emotie-row">

                <div class="emotie-label">
                    ${expresiiRO[emo]}
                </div>

                <div class="bar">
                    <div
                        class="fill"
                        style="width:${val * 100}%">
                    </div>
                </div>

                <span>
                    ${Math.round(
                        val * 100
                    )}%
                </span>

            </div>

        `)

        .join("");

}


// =========================
// CONCLUZIE AI
// =========================

function genereazaConcluzie() {

    if (
        !emotieText ||
        !emotieCamera
    ) {
        return;
    }

    const concluzie =
        document.getElementById(
            "concluzie"
        );

    if (
        emotieText ===
        emotieCamera
    ) {

        concluzie.innerHTML =

            `✅ Textul și expresia facială indică aceeași emoție: <b>${emotieText}</b>.`;

        return;
    }

    concluzie.innerHTML =

        `🤔 Textul sugerează <b>${emotieText}</b>, iar expresia facială sugerează <b>${emotieCamera}</b>. AI observă o diferență între ceea ce este scris și ceea ce exprimă fața.`;

}