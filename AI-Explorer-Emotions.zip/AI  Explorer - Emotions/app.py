from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    send_from_directory
)

import unicodedata
import re

app = Flask(__name__)


EMOTII = {
    "fericit": [
        "fericit",
        "bine",
        "super",
        "vesel",
        "bucuros",
        "minunat",
        "excelent",
        "grozav"
    ],

    "trist": [
        "trist",
        "suparat",
        "dezamagit",
        "singur",
        "obosit"
    ],

    "anxios": [
        "anxios",
        "stresat",
        "ingrijorat",
        "teama",
        "panica"
    ],

    "furios": [
        "furios",
        "nervos",
        "enervat",
        "iritat"
    ]
}


EMOJI = {
    "fericit": "😊",
    "trist": "😢",
    "anxios": "😨",
    "furios": "😠",
    "neutru": "😐"
}


def elimina_diacritice(text):
    return ''.join(
        caracter
        for caracter in unicodedata.normalize(
            'NFD',
            text
        )
        if unicodedata.category(caracter) != 'Mn'
    )


def proceseaza_text(text):

    text = text.lower()

    text = elimina_diacritice(text)

    text = re.sub(
        r"[^\w\s]",
        " ",
        text
    )

    return text


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/models/<path:filename>")
def models(filename):
    return send_from_directory(
        "models",
        filename
    )


@app.route("/analiza", methods=["POST"])
def analiza():

    try:

        data = request.get_json()

        if not data:
            return jsonify({
                "error":
                "Nu am primit date."
            }), 400

        text = data.get(
            "text",
            ""
        )

        if not text.strip():
            return jsonify({
                "error":
                "Textul este gol."
            }), 400

        text = proceseaza_text(text)

        cuvinte_text = text.split()

        scoruri = {
            emotie: 0
            for emotie in EMOTII
        }

        for emotie, cuvinte in EMOTII.items():

            for cuvant in cuvinte:

                if cuvant in cuvinte_text:
                    scoruri[emotie] += 1

        scor_maxim = max(
            scoruri.values()
        )

        if scor_maxim == 0:

            emotie_dominanta = "neutru"

        else:

            emotii_maxime = [

                emotie

                for emotie, scor
                in scoruri.items()

                if scor == scor_maxim

            ]

            emotie_dominanta = (
                emotii_maxime[0]
            )

        return jsonify({

            "emotie":
                emotie_dominanta,

            "emoji":
                EMOJI[
                    emotie_dominanta
                ],

            "scoruri":
                scoruri

        })

    except Exception as eroare:

        return jsonify({

            "error":
                str(eroare)

        }), 500


if __name__ == "__main__":
    app.run(
        debug=True
    )